import * as React from 'react';
import * as ReactDOM from 'react-dom';


/**
 * Chapter 2 - Creating JSX elements
 */
// Variable definitions outside of functions
let languageName = "React";
let introduction = `Hello ${languageName}, my new friend 😝`;

// This is the syntax to define a component class
class MyComponent extends React.Component {
    render() {
        return (
            <section>
                {introduction}
            </section>
        )
    }
}

/**
 *
 */
// This is the statement which executes the root function
const root = ReactDOM.createRoot(document.getElementById("root"));

// This statement is what renders the actual component class
root.render(<MyComponent/>);